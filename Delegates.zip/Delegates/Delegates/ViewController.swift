//
//  ViewController.swift
//  Delegates
//
//  Created by TOPS on 8/20/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate,UIPickerViewDelegate,UIPickerViewDataSource {

    @IBOutlet weak var web: UIWebView!
    let arr=["MacOS","IPhone","IOS"]
    let arr1=["Mac","iphone","ios"]
    override func viewDidLoad() {
        super.viewDidLoad()
        dpicker.isHidden=true
        let dt = Date()
        let frm=DateFormatter()
        frm.dateFormat="dd-MM-yyyy"
        txt3.text=frm.string(from: dt)
        // Do any additional setup after loading the view, typically from a nib.
        /*let url = URL(string: "https://www.google.com/")
        web.loadRequest(URLRequest.init(url:url!))*/
        /*let path = Bundle.main.path(forResource: "xmltutorial", ofType: "pdf")
        let url=URL(string: path!)
        web.loadRequest(URLRequest.init(url: url!))*/
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if component==0
        {
            return arr.count
        }
        else
        {   return arr1.count
        }
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if component==0
        {   return arr[row]
        }
        else
        {   return arr1[row]
        }
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if component==0
        {   print(arr[row])
        }
        else
        {   print(arr1[row])
        }
    }
    @IBAction func dpickerAction(_ sender: Any) {
        let dt = dpicker.date
        let frm=DateFormatter()
        frm.dateFormat="dd-MM-yyyy"
        txt3.text=frm.string(from: dt)
        dpicker.isHidden=true
    }
    @IBOutlet weak var txt1: UITextField!
    @IBOutlet weak var dpicker: UIDatePicker!
    @IBOutlet weak var txt2: UITextField!
    @IBOutlet weak var txt3: UITextField!
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return self.view.endEditing(true)
    }
    
    @IBAction func txtClick(_ sender: Any)
    {   let alt = UIAlertController(title: "Information", message: "THIS IS INFORMATION", preferredStyle: .actionSheet)
        /*alt.addTextField
        {   txtName in
            txtName.placeholder="Enter name..."
        }*/
        let OK=UIAlertAction(title: "OK", style: .default, handler: nil)
        alt.addAction(OK)
        self.present(alt, animated: true, completion: nil)
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if textField.tag==0
        {   dpicker.isHidden=true
            return true
        }
        else if textField.tag==1
        {   self.view.endEditing(true)
            dpicker.isHidden=true
            return false
        }
        else if textField.tag==2
        {   self.view.endEditing(true)
            dpicker.isHidden=false
            return false
        }
        else
        {   return true
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

